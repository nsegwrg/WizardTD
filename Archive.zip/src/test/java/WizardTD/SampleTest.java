package WizardTD;


//import processing.core.PApplet;
import org.junit.jupiter.api.Test;
//import static org.junit.jupiter.api.Assertions.*;

public class SampleTest {

    @Test
    public void simpleTest() {
        
    }
}
